import { LightningElement, track, api,wire } from 'lwc';
import searchAccounts from '@salesforce/apex/PartyDetailsController.searchAccounts';
import getAccountDetails from '@salesforce/apex/PartyDetailsController.getAccountDetails';
import getAccountDetailsFromAppForm from '@salesforce/apex/PartyDetailsController.getAccountDetailsFromAppForm';
import getApplicantsFromAppForm from '@salesforce/apex/PartyDetailsController.getApplicantsFromAppForm';
import { getObjectInfo, getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
import saveApplicant from '@salesforce/apex/PartyDetailsController.saveApplicant';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import APPLICANT_OBJECT from '@salesforce/schema/Applicant';
import { OmniscriptBaseMixin } from 'omnistudio/omniscriptBaseMixin';

export default class PartyDetails extends OmniscriptBaseMixin(LightningElement) {
    @api recordId; // ApplicationForm Id
    @track searchKey = '';
    @track searchResults = [];
    @track formData = {};
    @track selectedAccountId;
    @track applicants = [];

    @track newApplicant = null;

     @track industryOptions = [];
    @track legalEntityOptions = [];
    @track roleOptions = [];

    @track industryAppOptions = [];
    @track legalEntityAppOptions = [];
    @track roleAppOptions = [];

   // For Account object picklists
@wire(getObjectInfo, { objectApiName: ACCOUNT_OBJECT })
accountObjectInfo;

@wire(getPicklistValuesByRecordType, { objectApiName: ACCOUNT_OBJECT, recordTypeId: '$accountObjectInfo.data.defaultRecordTypeId' })
wiredAccountPicklistValues({ data, error }) {
    if (data) {
        this.industryOptions = data.picklistFieldValues.Industry.values;
        this.legalEntityOptions = data.picklistFieldValues.Legal_Entity__c.values;
        this.roleOptions = data.picklistFieldValues.Role__c.values;
    } else if (error) {
        console.error('Account picklist error', error);
    }
}

// For Applicant object picklists
@wire(getObjectInfo, { objectApiName: APPLICANT_OBJECT })
applicantObjectInfo;

@wire(getPicklistValuesByRecordType, { objectApiName: APPLICANT_OBJECT, recordTypeId: '$applicantObjectInfo.data.defaultRecordTypeId' })
wiredApplicantPicklistValues({ data, error }) {
    if (data) {
        this.industryAppOptions = data.picklistFieldValues.Industry__c.values;
        this.legalEntityAppOptions = data.picklistFieldValues.Legal_Entity__c.values;
        this.roleAppOptions = data.picklistFieldValues.Role.values;
    } else if (error) {
        console.error('Applicant picklist error', error);
    }
}

    @track showForm = false;
    @api formData = {};     // Read-only data
    @track editData = {};   // Editable form data
    @track isReadOnly = true;

    handleEdit() {
        this.editData = { ...this.formData };
        this.isReadOnly = false;
    }

    handleCancel() {
        this.isReadOnly = true;
    }

    handleInputChange(event) {
        const field = event.target.dataset.field;
        this.editData = { ...this.editData, [field]: event.target.value };
    }

   async handleSave() {
    try {
        // Ensure we carry Id properly
        if (this.editData.id && !this.editData.Id) {
            this.editData.Id = this.editData.id;
            delete this.editData.id;
        }

        const applicantToSave = {
            Id: this.editData.Id,  //  required for update
            ApplicationFormId: this.recordId,
            Company_Name__c: this.editData.companyName,
            Role: this.editData.role,
            DBA__c: this.editData.dba,
            Industry__c: this.editData.industry,
            Employees__c: this.editData.employees,
            Annual_Revenue__c: this.editData.annualRevenue,
            Net_Profit__c: this.editData.netProfit,
            Legal_Entity__c: this.editData.legalEntity,
            Comments__c: this.editData.comment
        };

        console.log('Saving applicant:', JSON.stringify(applicantToSave));

        const result = await saveApplicant({ applicant: applicantToSave });

        // Refresh with latest DB values (Id now guaranteed)
        this.formData = { ...result };
        this.editData = { ...result };
        this.isReadOnly = true;

        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Success',
                message: 'Applicant saved successfully',
                variant: 'success'
            })
        );

    } catch (error) {
        console.error('Save error:', error);
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Error saving applicant',
                message: error?.body?.message || error.message,
                variant: 'error'
            })
        );
    }
}

    connectedCallback() {
        console.log('ApplicationForm Id', this.recordId);
        if (this.recordId) {
            this.prefillFromAppForm();
            this.loadApplicants();
        }
    }

    


  async prefillFromAppForm() {
    try {
        const applicants = await getApplicantsFromAppForm({ appFormId: this.recordId });

        if (applicants && applicants.length > 0) {
            // Use existing applicant
            const app = applicants[0];
            this.formData = {
                Id: app.Id,  
                companyName: app.Company_Name__c,
                role: app.Role__c,
                dba: app.DBA__c,
                industry: app.Industry__c,
                employees: app.Employees__c,
                annualRevenue: app.Annual_Revenue__c,
                netProfit: app.Net_Profit__c,
                legalEntity: app.Legal_Entity__c,
                comment: app.Comments__c,
                ApplicationFormId: this.recordId
            };
        } else {
            // No applicant yet → fallback to Account
            const accountDetails = await getAccountDetailsFromAppForm({ appFormId: this.recordId });
            this.formData = {
                Id: null,
                companyName: accountDetails.Name,
                role: accountDetails.Role__c,
                dba: accountDetails.nSBA__DBA__c,
                industry: accountDetails.Industry,
                employees: accountDetails.NumberOfEmployees,
                annualRevenue: accountDetails.AnnualRevenue,
                netProfit: accountDetails.Net_Profit__c,
                legalEntity: accountDetails.Legal_Entity__c,
                comment: accountDetails.Comments__c,
                ApplicationFormId: this.recordId
            };
        }

        this.editData = { ...this.formData };
        this.selectedAccountId = this.formData.Id;

    } catch (error) {
        console.error('Error prefill:', error);
    }
}


    async loadApplicants() {
    try {
        const fetchedApplicants = await getApplicantsFromAppForm({ appFormId: this.recordId });
        if (fetchedApplicants && fetchedApplicants.length > 0) {
            this.applicants = fetchedApplicants.map(app => {
                // Defensive copy and initialization
                const applicantData = { ...app };
                return {
                    ...applicantData,
                    label: (app.Company_Name__c || '') + (app.Company_Name__c && app.Role ? ' - ' : '') + (app.Role || ''),
                    isReadOnly: true,
                    // Create a separate copy for editing to avoid direct mutation
                    editData: { ...applicantData } 
                };
            });
            console.log('Loaded and initialized applicants:', this.applicants);
        } else {
            this.applicants = []; // Ensure it's an empty array if no data
        }
    } catch (error) {
        console.error('Error fetching and initializing applicants', error);
        this.applicants = []; // Handle the error by setting to an empty array
    }
}

    addApplicant() {
        this.newApplicant = {
            searchKey: '',
            searchResults: [],
            Company_Name__c: '',
            Role: '',
            DBA__c: '',
            Industry__c: '',
            Employees__c: null,
            Annual_Revenue__c: '',
            Net_Profit__c: '',
            Legal_Entity__c: '',
            Comments__c: ''
        };
    }

    handleNewApplicantFieldChange(event) {
    const field = event.target.label.replace(/ /g, '_'); // replace spaces with underscores
    this.newApplicant = { ...this.newApplicant, [field]: event.target.value };
}

handleNewApplicantAccountSelect(event) {
    const selectedId = event.currentTarget.dataset.id;
    const selectedAccount = this.newApplicant.searchResults.find(acc => acc.Id === selectedId);

    if (selectedAccount) {
        // Assign picklist only if value exists in options
        const industryValue = this.industryOptions.find(opt => opt.value === selectedAccount.Industry)?.value || '';
        const legalEntityValue = this.legalEntityOptions.find(opt => opt.value === selectedAccount.Legal_Entity__c)?.value || '';
        const roleValue = this.roleOptions.find(opt => opt.value === selectedAccount.Role__c)?.value || '';

        this.newApplicant = {
            ...this.newApplicant,
            AccountId: selectedAccount.Id,
            Company_Name__c: selectedAccount.Name,
            DBA__c: selectedAccount.DBA__c || '',
            Industry__c: industryValue,
            Employees__c: selectedAccount.NumberOfEmployees || '',
            Annual_Revenue__c: selectedAccount.AnnualRevenue || '',
            Net_Profit__c: selectedAccount.Net_Profit__c || '',
            Legal_Entity__c: legalEntityValue,
            Role: roleValue,
            Comments__c: ''
        };

        this.newApplicant.searchResults = [];
        this.newApplicant.searchKey = selectedAccount.Name;
    }
}
   
    handleNewApplicantSearchKeyChange(event) {
    this.newApplicant.searchKey = event.target.value;

    if(this.newApplicant.searchKey.length > 2){
        searchAccounts({ searchKey: this.newApplicant.searchKey })
        .then(result => {
            this.newApplicant.searchResults = result;
        })
        .catch(error => {
            this.newApplicant.searchResults = [];
            console.error(error);
        });
    } else {
        this.newApplicant.searchResults = [];
    }
}



    async findAccounts(searchKey) {
        try {
            const results = await searchAccounts({ searchKey });
            this.newApplicant.searchResults = results;
        } catch (error) {
            console.error(error);
        }
    }

   
    handleSearchKeyChange(event) {
        this.searchKey = event.target.value;
        if (this.searchKey.length > 1) {
            this.findAccounts();
        } else {
            this.searchResults = [];
        }
    }

    async findAccounts() {
        try {
            this.searchResults = await searchAccounts({ searchKey: this.searchKey });
        } catch (error) {
            console.error('Error searching accounts:', error);
        }
    }

    async handleAccountSelect(event) {
        this.selectedAccountId = event.currentTarget.dataset.id;
        this.searchResults = [];
        try {
            const details = await getAccountDetails({ accountId: this.selectedAccountId });
            this.formData = { ...details };
            // Save as Applicant
          //  await createApplicant({ appFormId: this.recordId, accDetails: this.formData });
            this.loadApplicants(); // refresh
        } catch (error) {
            console.error('Error fetching account details:', error);
        }
    }

    handleApplicantSearchKeyChange(event) {
    const applicantId = event.target.dataset.id;
    const value = event.target.value;

    this.applicants = this.applicants.map(app => {
        if (app.Id === applicantId) {
            return { ...app, searchKey: value };
        }
        return app;
    });

    if (value.length > 1) {
        this.findAccountsForApplicant(applicantId, value);
    }
}

async findAccountsForApplicant(applicantId, searchKey) {
    try {
        const results = await searchAccounts({ searchKey });
        this.applicants = this.applicants.map(app => {
            if (app.Id === applicantId) {
                return { ...app, searchResults: results };
            }
            return app;
        });
    } catch (error) {
        console.error('Error searching accounts for applicant:', error);
    }
}

async handleApplicantAccountSelect(event) {
    const applicantId = event.currentTarget.dataset.applicantId;
    const accountId = event.currentTarget.dataset.id;

    try {
        const details = await getAccountDetails({ accountId });
        this.applicants = this.applicants.map(app => {
            if (app.Id === applicantId) {
                return { 
                    ...app, 
                    AccountId: accountId,
                    Company_Name__c: details.companyName,
                    Role : details.role,
                    DBA__c: details.dba,
                    Industry__c: details.industry,
                    Employees__c: details.employees,
                    Annual_Revenue__c: details.annualRevenue,
                    Net_Profit__c: details.netProfit,
                    Legal_Entity__c: details.legalEntity,
                    Comments__c: details.comment,
                    searchResults: []
                };
            }
            return app;
        });
    } catch (error) {
        console.error('Error fetching account details for applicant:', error);
    }
}

// New handler for the "Edit" button on an existing applicant
    handleEditApplicant(event) {
        const applicantId = event.target.dataset.id;
        this.applicants = this.applicants.map(app => {
            if (app.Id === applicantId) {
                return { ...app, isReadOnly: false }; // Make this specific applicant editable
            }
            return app;
        });
    }

    // New handler for the "Cancel" button on an existing applicant
    handleCancelApplicant(event) {
        const applicantId = event.target.dataset.id;
        this.applicants = this.applicants.map(app => {
            if (app.Id === applicantId) {
                // Revert to original data and make it read-only again
                return { ...app, isReadOnly: true, editData: { ...app } };
            }
            return app;
        });
    }

    // New handler to update a specific applicant's editData as fields change
    handleApplicantInputChange(event) {
        const applicantId = event.target.dataset.id;
        const field = event.target.dataset.field;
        const value = event.target.value;

        this.applicants = this.applicants.map(app => {
            if (app.Id === applicantId) {
                // Update the editData property for the specific field
                const updatedEditData = { ...app.editData, [field]: value };
                return { ...app, editData: updatedEditData };
            }
            return app;
        });
    }

   // New handler to save the changes for a specific applicant
async handleSaveApplicant(event) {
    const applicantId = event.target.dataset.id;
    const applicantToSave = this.applicants.find(app => app.Id === applicantId);

    if (!applicantToSave) {
        console.error('Applicant not found in the list.');
        return;
    }

    try {
        // Create a clean object to send to Apex, containing only the fields to be updated.
        // This is crucial for matching the Apex method's expected input (Applicant sObject).
        const applicantDataForApex = {
            Id: applicantId, // The ID is essential for the update
            ApplicationFormId: this.recordId,
            Company_Name__c: applicantToSave.editData.Company_Name__c,
            Role: applicantToSave.editData.Role,
            DBA__c: applicantToSave.editData.DBA__c,
            Industry__c: applicantToSave.editData.Industry__c,
            Employees__c: applicantToSave.editData.Employees__c,
            Annual_Revenue__c: applicantToSave.editData.Annual_Revenue__c,
            Net_Profit__c: applicantToSave.editData.Net_Profit__c,
            Legal_Entity__c: applicantToSave.editData.Legal_Entity__c,
            Comments__c: applicantToSave.editData.Comments__c
        };

        const result = await saveApplicant({ applicant: applicantDataForApex });
        console.log('Saved applicant:', result);

        this.applicants = this.applicants.map(app => {
            if (app.Id === applicantId) {
                // Update the main applicant object with the saved data from Apex
                return {
                    ...result, // 'result' is the updated Applicant record from Apex
                    isReadOnly: true,
                    editData: { ...result }
                };
            }
            return app;
        });

        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Success',
                message: 'Applicant saved successfully.',
                variant: 'success'
            })
        );

    } catch (error) {
        console.error('Save error:', error);
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Error saving applicant',
                message: error?.body?.message || error.message,
                variant: 'error'
            })
        );
    }
}



 // Show form
    handleAddBusiness() {
        this.showForm = true;
        this.formData = {};
        this.selectedAccount = null;
        this.searchResults = [];
    }

    // Account search
    handleSearchKeyChange(event) {
        this.searchKey = event.target.value;
        if (this.searchKey.length > 2) {
            searchAccounts({ searchKey: this.searchKey })
                .then(result => {
                    this.searchResults = result;
                })
                .catch(error => {
                    console.error(error);
                    this.searchResults = [];
                });
        } else {
            this.searchResults = [];
        }
    }

    // Account selection
    async handleAccountSelect(event) {
        const accountId = event.currentTarget.dataset.id;
        this.selectedAccount = accountId;
        this.searchResults = [];

        try {
            const details = await getAccountDetails({ accountId });
            this.formData = {
                AccountId: details.id,
                Company_Name__c: details.companyName,
                DBA__c: details.dba,
                Industry__c: details.industry,
                Employees__c: details.employees,
                Annual_Revenue__c: details.annualRevenue,
                Net_Profit__c: details.netProfit,
                Legal_Entity__c: details.legalEntity,
                Comments__c: details.comment
            };
        } catch (error) {
            console.error('Error fetching account details:', error);
        }
    }

    // Handle input change
    handleInputChange(event) {
        const field = event.target.label.replace(/\s+/g, '_'); // Match API field mapping
        this.formData[field] = event.target.value;
    }

    // Save applicant
    async handleSaveApplicant() {
        try {
            const applicantRecord = {
                ApplicationFormId: this.recordId,
                ...this.formData
            };

            await saveApplicant({ applicant: applicantRecord });

            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Applicant saved successfully',
                    variant: 'success'
                })
            );

            this.showForm = false;
            this.formData = {};
            this.selectedAccount = null;
        } catch (error) {
            console.error('Save error:', error);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: error?.body?.message || error.message,
                    variant: 'error'
                })
            );
        }
    }

}